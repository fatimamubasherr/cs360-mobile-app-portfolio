package com.example.cs360_projecttwo_fati;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101;
    public static final String SETTINGS_PREFS = "InventorySettings";
    public static final String KEY_SMS_ENABLED = "sms_enabled";
    public static final String KEY_THRESHOLD = "global_threshold";

    private Switch switchSms;
    private EditText editThreshold;
    private Button buttonSaveSettings;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        sharedPreferences = getSharedPreferences(SETTINGS_PREFS, MODE_PRIVATE);

        switchSms = findViewById(R.id.switchSms);
        editThreshold = findViewById(R.id.editThreshold);
        buttonSaveSettings = findViewById(R.id.buttonSaveSettings);

        loadSavedSettings();

        switchSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (buttonView.isPressed()) {
                if (isChecked) {
                    checkSmsPermission();
                } else {
                    sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                    Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSaveSettings.setOnClickListener(v -> saveSettings());
    }

    private void loadSavedSettings() {
        boolean smsEnabled = sharedPreferences.getBoolean(KEY_SMS_ENABLED, false);
        int threshold = sharedPreferences.getInt(KEY_THRESHOLD, 5);

        switchSms.setChecked(smsEnabled);
        editThreshold.setText(String.valueOf(threshold));
    }

    private void saveSettings() {
        String thresholdText = editThreshold.getText().toString().trim();

        if (TextUtils.isEmpty(thresholdText)) {
            Toast.makeText(this, "Enter a threshold value", Toast.LENGTH_SHORT).show();
            return;
        }

        int threshold = Integer.parseInt(thresholdText);
        boolean smsEnabled = switchSms.isChecked();

        sharedPreferences.edit()
                .putInt(KEY_THRESHOLD, threshold)
                .putBoolean(KEY_SMS_ENABLED, smsEnabled)
                .apply();

        Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show();
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE);
        } else {
            sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
            Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, true).apply();
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                sharedPreferences.edit().putBoolean(KEY_SMS_ENABLED, false).apply();
                Toast.makeText(this, "SMS permission denied. App will still work without it.", Toast.LENGTH_LONG).show();
                switchSms.setChecked(false);
            }
        }
    }
}