package com.example.cs360_projecttwo_fati;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editQuantity;
    private EditText editThreshold;
    private Button buttonSave;
    private Button buttonCancel;
    private DatabaseHelper databaseHelper;
    private boolean isEditMode = false;
    private String originalItemName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);
        editThreshold = findViewById(R.id.editThreshold);
        buttonSave = findViewById(R.id.buttonSave);
        buttonCancel = findViewById(R.id.buttonCancel);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("item_name")) {
            isEditMode = true;
            originalItemName = intent.getStringExtra("item_name");
            editItemName.setText(intent.getStringExtra("item_name"));
            editQuantity.setText(String.valueOf(intent.getIntExtra("item_quantity", 0)));
            editThreshold.setText(String.valueOf(intent.getIntExtra("item_threshold", 0)));
            buttonSave.setText("Update Item");
        }

        buttonSave.setOnClickListener(v -> saveItem());
        buttonCancel.setOnClickListener(v -> finish());
    }

    private void saveItem() {
        String itemName = editItemName.getText().toString().trim();
        String quantityText = editQuantity.getText().toString().trim();
        String thresholdText = editThreshold.getText().toString().trim();

        if (TextUtils.isEmpty(itemName) || TextUtils.isEmpty(quantityText) || TextUtils.isEmpty(thresholdText)) {
            Toast.makeText(this, "Fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        int threshold;

        try {
            quantity = Integer.parseInt(quantityText);
            threshold = Integer.parseInt(thresholdText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success;

        if (isEditMode) {
            success = databaseHelper.updateItemByName(originalItemName, itemName, quantity, threshold);
            if (success) {
                Toast.makeText(this, "Item updated successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to update item", Toast.LENGTH_SHORT).show();
            }
        } else {
            success = databaseHelper.insertItem(itemName, quantity, threshold);
            if (success) {
                Toast.makeText(this, "Item added successfully", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
