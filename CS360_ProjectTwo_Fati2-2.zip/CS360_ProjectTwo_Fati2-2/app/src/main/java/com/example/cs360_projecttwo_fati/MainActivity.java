package com.example.cs360_projecttwo_fati;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Typeface;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput;
    private EditText passwordInput;
    private Button loginButton;
    private Button createButton;
    private DatabaseHelper databaseHelper;
    private String lastLoadedItemName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        databaseHelper = new DatabaseHelper(this);
        showLoginScreen();
    }

    private void showLoginScreen() {
        setContentView(R.layout.activity_main);
        applyInsets();

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginBtn);
        createButton = findViewById(R.id.createBtn);

        loginButton.setOnClickListener(v -> handleLogin());
        createButton.setOnClickListener(v -> handleCreateAccount());
    }

    private void handleCreateAccount() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (databaseHelper.userExists(username)) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = databaseHelper.insertUser(username, password);

        if (inserted) {
            Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleLogin() {
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean validUser = databaseHelper.checkUser(username, password);

        if (validUser) {
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            showInventoryScreen();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    private void showInventoryScreen() {
        setContentView(R.layout.activity_inventory);
        applyInsets();

        ImageButton buttonSettings = findViewById(R.id.buttonSettings);
        if (buttonSettings != null) {
            buttonSettings.setOnClickListener(v ->
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        }

        com.google.android.material.floatingactionbutton.FloatingActionButton fabAddItem =
                findViewById(R.id.fabAddItem);

        if (fabAddItem != null) {
            fabAddItem.setOnClickListener(v ->
                    startActivity(new Intent(MainActivity.this, AddItemActivity.class)));
        }

        loadInventoryItems();

    }

    private void openEditItem(String itemName, int quantity, int threshold) {
        Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
        intent.putExtra("item_name", itemName);
        intent.putExtra("item_quantity", quantity);
        intent.putExtra("item_threshold", threshold);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            loadInventoryItems();
        } catch (Exception e) {
            // Ignore refresh attempts while the login screen is active.
        }
    }

    private void loadInventoryItems() {
        LinearLayout inventoryItemsContainer = findViewById(R.id.inventoryItemsContainer);
        TextView textEmptyState = findViewById(R.id.textEmptyState);
        TextView textInventoryCount = findViewById(R.id.textInventoryCount);

        if (inventoryItemsContainer == null || textEmptyState == null) {
            return;
        }

        Cursor cursor = databaseHelper.getAllItems();

        inventoryItemsContainer.removeAllViews();

        if (cursor == null || cursor.getCount() == 0) {
            textEmptyState.setVisibility(View.VISIBLE);
            inventoryItemsContainer.addView(textEmptyState);
            if (textInventoryCount != null) {
                textInventoryCount.setText("0 items");
            }
            if (cursor != null) {
                cursor.close();
            }
            return;
        }

        textEmptyState.setVisibility(View.GONE);

        lastLoadedItemName = "";
        int itemCount = cursor.getCount();
        int cardMarginBottom = dpToPx(12);

        while (cursor.moveToNext()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
            int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_QUANTITY));
            int threshold = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_THRESHOLD));
            lastLoadedItemName = itemName;

            int cardPadding = dpToPx(16);

            LinearLayout itemCard = new LinearLayout(this);
            itemCard.setOrientation(LinearLayout.VERTICAL);
            itemCard.setBackgroundColor(0xFFFFFFFF);
            itemCard.setPadding(cardPadding, cardPadding, cardPadding, cardPadding);
            itemCard.setElevation(3f);

            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            cardParams.bottomMargin = cardMarginBottom;
            itemCard.setLayoutParams(cardParams);

            TextView itemNameView = new TextView(this);
            itemNameView.setText(itemName);
            itemNameView.setTextSize(17);
            itemNameView.setTypeface(null, Typeface.BOLD);
            itemNameView.setTextColor(0xFF111827);

            TextView quantityView = new TextView(this);
            quantityView.setText("Quantity: " + quantity);
            quantityView.setTextSize(15);
            quantityView.setTextColor(0xFF374151);
            quantityView.setPadding(0, dpToPx(10), 0, 0);

            TextView thresholdView = new TextView(this);
            thresholdView.setText("Low-stock threshold: " + threshold);
            thresholdView.setTextSize(15);
            thresholdView.setTextColor(0xFF374151);
            thresholdView.setPadding(0, dpToPx(6), 0, 0);

            if (quantity <= threshold) {
                itemCard.setBackgroundColor(0xFFFFF1F2);
                thresholdView.setTextColor(0xFFB91C1C);
            }

            TextView actionHintView = new TextView(this);
            actionHintView.setText("Tap to edit • Long-press to delete");
            actionHintView.setTextSize(12);
            actionHintView.setTextColor(0xFF6B7280);
            actionHintView.setGravity(Gravity.START);
            actionHintView.setPadding(0, dpToPx(14), 0, 0);

            itemCard.addView(itemNameView);
            itemCard.addView(quantityView);
            itemCard.addView(thresholdView);
            itemCard.addView(actionHintView);

            itemCard.setOnClickListener(v -> openEditItem(itemName, quantity, threshold));
            itemCard.setOnLongClickListener(v -> {
                boolean deleted = databaseHelper.deleteItemByName(itemName);

                if (deleted) {
                    Toast.makeText(this, "Deleted: " + itemName, Toast.LENGTH_SHORT).show();
                    loadInventoryItems();
                } else {
                    Toast.makeText(this, "Failed to delete item", Toast.LENGTH_SHORT).show();
                }
                return true;
            });

            inventoryItemsContainer.addView(itemCard);
        }

        if (textInventoryCount != null) {
            textInventoryCount.setText(itemCount + (itemCount == 1 ? " item" : " items"));
        }
        cursor.close();
    }

    private int dpToPx(int dp) {
        return Math.round(getResources().getDisplayMetrics().density * dp);
    }

    private void applyInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}